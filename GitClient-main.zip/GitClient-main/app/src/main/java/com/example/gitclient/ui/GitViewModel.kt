package com.example.gitclient.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.gitclient.data.Commit
import com.example.gitclient.data.GitRepository
import com.example.gitclient.data.Net
import com.example.gitclient.data.Provider
import com.example.gitclient.data.Repo
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException

sealed interface UiState<out T> {
    object Idle : UiState<Nothing>
    object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

class GitViewModel : ViewModel() {
    private val repository = GitRepository()

    // поля формы
    var provider by mutableStateOf(Provider.GITHUB)
    var username by mutableStateOf("")
    var token by mutableStateOf("")

    var reposState by mutableStateOf<UiState<List<Repo>>>(UiState.Idle)
        private set
    var commitsState by mutableStateOf<UiState<List<Commit>>>(UiState.Idle)
        private set
    var selectedRepo by mutableStateOf<Repo?>(null)
        private set

    fun loadRepos() {
        if (username.isBlank()) {
            reposState = UiState.Error("Введи username")
            return
        }
        Net.setToken(provider, token)
        reposState = UiState.Loading
        viewModelScope.launch {
            reposState = try {
                UiState.Success(repository.repos(provider, username.trim()))
            } catch (e: Exception) {
                UiState.Error(errorText(e))
            }
        }
    }

    fun openRepo(repo: Repo) {
        selectedRepo = repo
        commitsState = UiState.Idle
    }

    fun loadCommits() {
        val repo = selectedRepo ?: return
        commitsState = UiState.Loading
        viewModelScope.launch {
            commitsState = try {
                UiState.Success(repository.commits(repo))
            } catch (e: Exception) {
                UiState.Error(errorText(e))
            }
        }
    }

    private fun errorText(e: Exception): String = when (e) {
        is HttpException -> when (e.code()) {
            404 -> "Не найдено (404). Проверь username"
            401 -> "Неверный токен (401)"
            403, 429 -> "Лимит API (${e.code()}). Добавь токен"
            409 -> "Репозиторий пустой (409)"
            else -> "Ошибка сервера: ${e.code()}"
        }
        is IOException -> "Нет интернета"
        else -> e.message ?: "Неизвестная ошибка"
    }
}
