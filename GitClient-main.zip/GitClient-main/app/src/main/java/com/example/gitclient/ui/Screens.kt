@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.gitclient.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.gitclient.data.Commit
import com.example.gitclient.data.Provider
import com.example.gitclient.data.Repo

/* ====================== Экран 1: поиск и список репозиториев ====================== */
@Composable
fun ReposScreen(vm: GitViewModel, onOpen: (Repo) -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("Git клиент") }) }) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 16.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Provider.values().forEach { p ->
                    FilterChip(
                        selected = vm.provider == p,
                        onClick = { vm.provider = p },
                        label = { Text(p.title) }
                    )
                }
            }
            OutlinedTextField(
                value = vm.username,
                onValueChange = { vm.username = it },
                label = { Text("Username") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
            OutlinedTextField(
                value = vm.token,
                onValueChange = { vm.token = it },
                label = { Text("Токен (необязательно)") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
            Button(
                onClick = vm::loadRepos,
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
            ) { Text("Найти репозитории") }

            when (val s = vm.reposState) {
                UiState.Idle -> Centered("Введи username и жми «Найти»")
                UiState.Loading -> Loading()
                is UiState.Error -> Centered(s.message)
                is UiState.Success ->
                    if (s.data.isEmpty()) Centered("Репозиториев нет")
                    else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(s.data, key = { it.id }) { RepoItem(it) { onOpen(it) } }
                    }
            }
        }
    }
}

@Composable
private fun RepoItem(repo: Repo, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(repo.name, style = MaterialTheme.typography.titleMedium)
            if (!repo.description.isNullOrBlank()) {
                Text(
                    repo.description,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            val meta = buildList {
                add("★ ${repo.stars}")
                repo.language?.let { add(it) }
            }.joinToString("  ·  ")
            Text(meta, style = MaterialTheme.typography.bodySmall)
        }
    }
}

/* ====================== Экран 2: коммиты выбранного репозитория ====================== */
@Composable
fun CommitsScreen(vm: GitViewModel, onBack: () -> Unit) {
    val repo = vm.selectedRepo
    LaunchedEffect(repo?.id) { vm.loadCommits() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(repo?.fullName ?: "Коммиты", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = onBack) { Text("←") } }
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).padding(horizontal = 16.dp).fillMaxSize()) {
            when (val s = vm.commitsState) {
                UiState.Idle, UiState.Loading -> Loading()
                is UiState.Error -> Centered(s.message)
                is UiState.Success ->
                    if (s.data.isEmpty()) Centered("Коммитов нет")
                    else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(s.data, key = { it.sha }) { CommitItem(it) }
                    }
            }
        }
    }
}

@Composable
private fun CommitItem(c: Commit) {
    val uriHandler = LocalUriHandler.current
    Card(
        onClick = { c.url?.let { runCatching { uriHandler.openUri(it) } } },
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(
                c.message.lineSequence().firstOrNull().orEmpty(),
                style = MaterialTheme.typography.titleSmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                "${c.author}  ·  ${c.date.replace("T", " ").take(16)}",
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                c.sha.take(7),
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

/* ====================== Общие кусочки ====================== */
@Composable
private fun Loading() = Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }

@Composable
private fun Centered(text: String) =
    Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) { Text(text) }
