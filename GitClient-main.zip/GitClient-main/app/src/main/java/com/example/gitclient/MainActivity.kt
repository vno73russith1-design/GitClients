package com.example.gitclient

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.gitclient.ui.CommitsScreen
import com.example.gitclient.ui.GitViewModel
import com.example.gitclient.ui.ReposScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface { App() }
            }
        }
    }
}

@Composable
fun App(vm: GitViewModel = viewModel()) {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "repos") {
        composable("repos") {
            ReposScreen(vm) { repo ->
                vm.openRepo(repo)
                nav.navigate("commits")
            }
        }
        composable("commits") {
            CommitsScreen(vm) { nav.popBackStack() }
        }
    }
}
