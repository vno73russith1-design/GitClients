package com.example.gitclient.data

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/** Создаёт Retrofit-клиенты и подставляет токен (если он есть) в заголовки. */
object Net {
    @Volatile private var ghToken = ""
    @Volatile private var glToken = ""

    fun setToken(provider: Provider, token: String) {
        if (provider == Provider.GITHUB) ghToken = token.trim() else glToken = token.trim()
    }

    private fun client(headers: () -> Map<String, String>) = OkHttpClient.Builder()
        .addInterceptor { chain ->
            val b = chain.request().newBuilder()
            headers().forEach { (k, v) -> b.header(k, v) }
            chain.proceed(b.build())
        }
        .build()

    private fun retrofit(baseUrl: String, headers: () -> Map<String, String>) = Retrofit.Builder()
        .baseUrl(baseUrl)
        .client(client(headers))
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val github: GitHubApi by lazy {
        retrofit("https://api.github.com/") {
            buildMap {
                put("Accept", "application/vnd.github+json")
                if (ghToken.isNotBlank()) put("Authorization", "Bearer $ghToken")
            }
        }.create(GitHubApi::class.java)
    }

    val gitlab: GitLabApi by lazy {
        retrofit("https://gitlab.com/api/v4/") {
            buildMap {
                if (glToken.isNotBlank()) put("PRIVATE-TOKEN", glToken)
            }
        }.create(GitLabApi::class.java)
    }
}
