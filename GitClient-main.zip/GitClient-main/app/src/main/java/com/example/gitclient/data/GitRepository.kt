package com.example.gitclient.data

/** Прячет различия GitHub/GitLab: наружу отдаёт одни и те же Repo и Commit. */
class GitRepository {

    suspend fun repos(provider: Provider, user: String): List<Repo> = when (provider) {
        Provider.GITHUB -> Net.github.userRepos(user).map {
            Repo(
                id = it.id.toString(),
                name = it.name.orEmpty(),
                fullName = it.fullName.orEmpty(),
                description = it.description,
                stars = it.stars ?: 0,
                language = it.language,
                url = it.htmlUrl.orEmpty(),
                provider = provider
            )
        }
        Provider.GITLAB -> {
            val list = try {
                Net.gitlab.userProjects(user)
            } catch (e: retrofit2.HttpException) {
                if (e.code() == 404) Net.gitlab.groupProjects(user) else throw e
            }
            list.map {
                Repo(
                    id = it.id.toString(),
                    name = it.name.orEmpty(),
                    fullName = it.fullName.orEmpty(),
                    description = it.description,
                    stars = it.stars ?: 0,
                    language = null,
                    url = it.webUrl.orEmpty(),
                    provider = provider
                )
            }
        }
    }

    suspend fun commits(repo: Repo): List<Commit> = when (repo.provider) {
        Provider.GITHUB -> {
            val (owner, name) = repo.fullName.split("/", limit = 2)
            Net.github.commits(owner, name).map {
                Commit(
                    sha = it.sha.orEmpty(),
                    message = it.commit?.message.orEmpty(),
                    author = it.commit?.author?.name ?: "unknown",
                    date = it.commit?.author?.date.orEmpty(),
                    url = it.htmlUrl
                )
            }
        }
        Provider.GITLAB -> Net.gitlab.commits(repo.id.toLong()).map {
            Commit(
                sha = it.id.orEmpty(),
                message = it.message ?: it.title.orEmpty(),
                author = it.authorName ?: "unknown",
                date = it.createdAt.orEmpty(),
                url = it.webUrl
            )
        }
    }
}
