package com.example.gitclient.data

import com.google.gson.annotations.SerializedName

enum class Provider(val title: String) { GITHUB("GitHub"), GITLAB("GitLab") }

/** Единые модели, с которыми работает UI (не зависят от провайдера). */
data class Repo(
    val id: String,
    val name: String,
    val fullName: String,
    val description: String?,
    val stars: Int,
    val language: String?,
    val url: String,
    val provider: Provider
)

data class Commit(
    val sha: String,
    val message: String,
    val author: String,
    val date: String,
    val url: String?
)

/* ---------- DTO GitHub ---------- */
data class GhRepoDto(
    val id: Long,
    val name: String?,
    @SerializedName("full_name") val fullName: String?,
    val description: String?,
    @SerializedName("stargazers_count") val stars: Int?,
    val language: String?,
    @SerializedName("html_url") val htmlUrl: String?
)

data class GhCommitDto(
    val sha: String?,
    @SerializedName("html_url") val htmlUrl: String?,
    val commit: GhCommitInner?
)

data class GhCommitInner(val message: String?, val author: GhPerson?)
data class GhPerson(val name: String?, val date: String?)

/* ---------- DTO GitLab ---------- */
data class GlRepoDto(
    val id: Long,
    val name: String?,
    @SerializedName("path_with_namespace") val fullName: String?,
    val description: String?,
    @SerializedName("star_count") val stars: Int?,
    @SerializedName("web_url") val webUrl: String?
)

data class GlCommitDto(
    val id: String?,
    val title: String?,
    val message: String?,
    @SerializedName("author_name") val authorName: String?,
    @SerializedName("created_at") val createdAt: String?,
    @SerializedName("web_url") val webUrl: String?
)
