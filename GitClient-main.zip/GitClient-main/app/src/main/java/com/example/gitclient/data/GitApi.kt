package com.example.gitclient.data

import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface GitHubApi {
    @GET("users/{user}/repos")
    suspend fun userRepos(
        @Path("user") user: String,
        @Query("per_page") perPage: Int = 50,
        @Query("sort") sort: String = "updated"
    ): List<GhRepoDto>

    @GET("repos/{owner}/{repo}/commits")
    suspend fun commits(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Query("per_page") perPage: Int = 30
    ): List<GhCommitDto>
}

interface GitLabApi {
    @GET("users/{user}/projects")
    suspend fun userProjects(
        @Path("user") user: String,
        @Query("per_page") perPage: Int = 50,
        @Query("order_by") orderBy: String = "last_activity_at"
    ): List<GlRepoDto>

    @GET("projects/{id}/repository/commits")
    suspend fun commits(
        @Path("id") id: Long,
        @Query("per_page") perPage: Int = 30
    ): List<GlCommitDto>

    @GET("groups/{group}/projects")
    suspend fun groupProjects(
        @Path("group") group: String,
        @Query("per_page") perPage: Int = 50,
        @Query("order_by") orderBy: String = "last_activity_at"
    ): List<GlRepoDto>
}
